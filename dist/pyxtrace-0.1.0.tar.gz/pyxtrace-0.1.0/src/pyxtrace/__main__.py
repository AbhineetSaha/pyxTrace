"""
python -m pyxtrace   → behaves exactly like the `pyxtrace` console‑script
"""

from .cli import main

if __name__ == "__main__":
    main()